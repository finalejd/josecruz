from django.shortcuts import render

from django.views import generic

class Index(generic.View):
    template_name = "home/index.html"
    context={} #nivel
    
    def get(self, request):
        return render(request, self.template_name,self.context)
    
class About(generic.View):
    template_name = "home/about.html"
    context ={}
    
    def get(self, request, *args, **kwargs):
        return render(request, self.template_name,self.context)  
    
class Contact(generic.View):
    template_name = "home/contact.html"
    context ={}
    
    def get(self, request, *args, **kwargs):
        return render(request, self.template_name,self.context)  
    
    
#render es el obejto que se encarga de renderizar todo lo que esta en nuestra vista .py a nuestro html   
#def = definicion